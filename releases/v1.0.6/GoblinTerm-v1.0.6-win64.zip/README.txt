GoblinTerm Portable for Windows

This package is self-contained. End users do not need to install Python or any other development tools.

How to run:
1. Extract the full ZIP to a normal folder.
2. Keep all files together inside the extracted GoblinTerm folder.
3. Run GoblinTerm.exe.

Notes:
- Do not move GoblinTerm.exe out of this folder; it depends on bundled files beside it.
- Windows may show a SmartScreen warning for unsigned builds.
- Settings and session data are stored in your AppData profile, not inside this folder.

Support:
Use the public release repository/issues page for downloads and support.

