# xterm.js Local Assets

Place the following files in this folder to enable fully local xterm asset loading:

- xterm.min.css
- xterm.min.js
- xterm-addon-fit.min.js

When all three files exist, GoblinTerm uses local `file:///` URLs.
If any are missing, it falls back to CDN URLs.

Optional override:

- Set `GOBLINTERM_XTERM_ASSET_ROOT` to point to a custom asset directory.

Disable WebView usage entirely (force Tk fallback):

- Set `GOBLINTERM_DISABLE_WEBVIEW=1`
